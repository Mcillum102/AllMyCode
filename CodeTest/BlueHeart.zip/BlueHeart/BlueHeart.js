// P5.js (JavaScript) - Heart Animation with Sparkles

let sparkles = [];

function setup() {
  createCanvas(1550, 870);
  background(0);
  frameRate(60);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(255, 220, 255);
  translate(width / 2, height / 2);

  // Draw existing sparkles
  for (let i = sparkles.length - 1; i >= 0; i--) {
    sparkles[i].update();
    sparkles[i].display();
    if (sparkles[i].isFinished()) {
      sparkles.splice(i, 1);
    }
  }

  // Heart animation (pulsing)
  let scaleFactor = 1 + 0.1 * sin(frameCount / 10.0);

  // Draw heart
  stroke(255, 0, 0);
  strokeWeight(2);
  fill(255, 0, 0);
  beginShape();
  for (let t = 0; t <= 360; t += 2) {
    let theta = radians(t);
    let point = heartShape(theta);
    vertex(point.x * scaleFactor * 10, -point.y * scaleFactor * 10);

    // Add sparkles randomly along heart shape
    if (random(100) < 2) {
      sparkles.push(new Sparkle(point.x * scaleFactor * 10, -point.y * scaleFactor * 10));
    }
  }
  endShape(CLOSE);

  // Animated text
  fill(255);
  textSize(20 + 2 * sin(frameCount / 10.0));
  text("Miss U tons", 0, -30);
  text("It's been a week", 0, 10);
  text("Love you 3000", 0, 50);

  fill(0);
  text("My Lovely Girl", 0, -140);
}

// Heart shape parametric equation
function heartShape(t) {
  let x = 16 * pow(sin(t), 3);
  let y = 13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t);
  return createVector(x, y);
}

// Sparkle class for sparkling effect
class Sparkle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(4, 8);
    this.lifespan = 255;
  }

  update() {
    this.lifespan -= 5;
  }

  display() {
    noStroke();
    fill(255, 215, 0, this.lifespan);  // Gold color with fading effect
    ellipse(this.x, this.y, this.size, this.size);
  }

  isFinished() {
    return this.lifespan <= 0;
  }
}
